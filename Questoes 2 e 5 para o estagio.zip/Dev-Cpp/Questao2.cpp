#include <iostream>

/*2)Dado a sequ�ncia de Fibonacci, onde se inicia por 0 e 1 e o pr�ximo valor sempre ser� a soma dos 2 valores anteriores (exemplo: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34...), escreva um programa na linguagem que desejar onde, informado um n�mero, ele calcule a sequ�ncia de Fibonacci e retorne uma mensagem avisando se o n�mero informado pertence ou n�o a sequ�ncia.



IMPORTANTE:

Esse n�mero pode ser informado atrav�s de qualquer entrada de sua prefer�ncia ou pode ser previamente definido no c�digo */



int main() {
    
    const int MAX_NUM = 1000;

    
    int a = 0, b = 1;

    
    std::cout << "Sequencia de Fibonacci: " << a << ", " << b;

    
    while(a + b <= MAX_NUM) {
        int next = a + b;
        std::cout << ", " << next;
        a = b;
        b = next;
    }

   
    int numeroInformado;
    std::cout << "\n\nInforme um numero: ";
    std::cin >> numeroInformado;

    
    int c = 0, d = 1;
    while (c <= numeroInformado) {
        if (c == numeroInformado) {
            std::cout << "\nO numero pertence a sequencia de Fibonacci.\n";
            return 0;
        }
        int next = c + d;
        c = d;
        d = next;
    }

    std::cout << "\nO Esse numero nao pertence a sequencia de Fibonacci.\n";

    return 0;
}

