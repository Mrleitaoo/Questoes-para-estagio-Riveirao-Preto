#define ID_MENU 501

#define IDM_FILENEW         200
#define IDM_FILEOPEN        201
#define IDM_FILESAVE        202
#define IDM_FILESAVEAS      203
#define IDM_FILEPRINT       204
#define IDM_FILEPAGESETUP   205
#define IDM_FILEPRINTSETUP  206
#define IDM_FILEEXIT        207

#define IDM_EDITUNDO        210
#define IDM_EDITCUT         211
#define IDM_EDITCOPY        212
#define IDM_EDITPASTE       213
#define IDM_EDITDELETE      214

#define IDM_HELPCONTENTS    215
#define IDM_HELPSEARCH      216
#define IDM_HELPHELP        217
#define IDM_HELPABOUT       218
