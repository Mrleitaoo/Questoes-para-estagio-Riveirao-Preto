#include <iostream>

/* Escreva um programa que inverta os caracteres de um string.


IMPORTANTE:

a) Essa string pode ser informada atrav�s de qualquer entrada de sua prefer�ncia ou pode ser previamente definida no c�digo;

b) Evite usar fun��es prontas, como, por exemplo, reverse;
using namespace std; */

int main() {
   
    const int TAMANHO_MAXIMO = 100;
    
    
    char minhaString[TAMANHO_MAXIMO];
    
   
    cout << "Digite uma palavra ou frase: ";
    cin.getline(minhaString, TAMANHO_MAXIMO);

   
    int comprimento = 0;
    while (minhaString[comprimento] != '\0') {
        comprimento++;
    }

    
    for (int i = 0; i < comprimento / 2; i++) {
        char temp = minhaString[i];
        minhaString[i] = minhaString[comprimento - i - 1];
        minhaString[comprimento - i - 1] = temp;
    }

    
    cout << "String invertida: " << minhaString << endl;

    return 0;
}
